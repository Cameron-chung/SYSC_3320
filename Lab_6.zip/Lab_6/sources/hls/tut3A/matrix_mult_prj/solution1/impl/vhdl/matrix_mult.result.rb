$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "16"
$LUT = "36"
$FF = "49"
$DSP = "1"
$BRAM ="0"
$SRL ="0"
#=== Final timing ===
$TargetCP = "5.000"
$CP = "3.704"
